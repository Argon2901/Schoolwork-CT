Known Issues:
The code requires an extra tick, completing everything in n + 1 ticks 
    where n is the total number of ticks the instructions would normally 
    take to make. 

